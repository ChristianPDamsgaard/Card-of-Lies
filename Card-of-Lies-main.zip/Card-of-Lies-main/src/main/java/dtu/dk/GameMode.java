package dtu.dk;

public class GameMode {
 
    

    public GameMode(){
        

    }


}
